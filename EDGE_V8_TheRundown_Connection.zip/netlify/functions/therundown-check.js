// Secure connectivity diagnostic; does NOT return the API key or imply that /markets is an odds feed.
exports.handler = async () => {
  const key = process.env.THERUNDOWN_API_KEY;
  if (!key) return { statusCode: 503, headers: {'Content-Type':'application/json','Cache-Control':'no-store'}, body: JSON.stringify({ok:false,error:'THERUNDOWN_API_KEY is not set in this Netlify deploy context'}) };
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    let response;
    try { response = await fetch('https://therundown.io/api/v2/markets', {headers:{'X-TheRundown-Key':key,'Accept':'application/json'},signal:controller.signal}); }
    finally { clearTimeout(timer); }
    const contentType = response.headers.get('content-type') || '';
    return { statusCode: response.ok ? 200 : 502, headers:{'Content-Type':'application/json','Cache-Control':'no-store'}, body:JSON.stringify({ok:response.ok,upstreamStatus:response.status,contentType,endpoint:'/api/v2/markets',note:response.ok?'API credential accepted for the documented markets endpoint. Sports odds endpoint and schema still need validation.':'TheRundown rejected or could not complete the request. Check key permissions and API plan.'}) };
  } catch(e) { return {statusCode:502,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify({ok:false,error:'Upstream request failed',reason:e.name==='AbortError'?'Timeout':e.message})}; }
};
