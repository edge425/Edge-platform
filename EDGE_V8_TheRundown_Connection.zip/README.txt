EDGE V8 / TheRundown secure connection check

This package preserves the existing EDGE V8 site and adds a secure Netlify Function for validating the TheRundown credential. It does NOT yet populate the odds columns: the documented /api/v2/markets endpoint needs to be checked before choosing a supported sports events/odds endpoint and normalizing its response. No simulated odds are shown.

Deploy the entire unzipped folder via a Netlify deployment method that builds functions (recommended: GitHub-connected Netlify site). A static-only GitHub Pages deployment cannot execute Netlify Functions. Depending on Netlify's manual deploy flow, drag-and-drop may not build functions; use Git-based deploy if the function URL returns 404.

Configure THERUNDOWN_API_KEY in Netlify project environment variables. Trigger a new deploy after saving it.

Visit https://YOUR-NETLIFY-DOMAIN/.netlify/functions/therundown-check

Expected: {"ok":true,"upstreamStatus":200,...}. If not, report the response JSON without revealing your key.

Security: This endpoint only reports status and content type; it never returns your API key or upstream response body. Regenerate the previously pasted key before deploying.
